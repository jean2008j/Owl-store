export const SIZES = ["XS", "S", "M", "L", "XL", "XXL", "3XL"] as const;
export type Size = (typeof SIZES)[number];

export const FITS = ["Oversize", "Boxy Fit", "Regular Fit"] as const;
export type Fit = (typeof FITS)[number];

export const TAGS = ["new", "bestsellers", "shirts", "hoodies", "tees", "jackets", "pants", "shorts", "sets"] as const;
export type Tag = (typeof TAGS)[number];

export const CATS = ["all", "new", "bestsellers", "shirts", "hoodies", "tees", "jackets", "pants", "shorts", "sets", "sale"] as const;
export type Cat = (typeof CATS)[number];

export type ProductColor = {
  id: string;
  name: string; // as typed in the admin (Arabic)
  nameEn?: string; // filled automatically (Arabic → English)
  nameAr?: string;
  hex: string;
};

export type Product = {
  id: string;
  slug: string;
  name: string; // as typed in the admin (Arabic)
  nameEn?: string; // filled automatically (Arabic → English)
  nameAr?: string;
  price: number;
  cost?: number | null; // what the piece costs you (admin only, never shown to customers)
  compareAt: number | null;
  tags: Tag[];
  description: string;
  descriptionEn?: string;
  descriptionAr?: string;
  details: string[];
  detailsEn?: string[];
  detailsAr?: string[];
  images: string[];
  video: string;
  colors: ProductColor[];
  fits: Fit[];
  /** Total per size (sum over all colours). Kept in sync with `colorStock`; old code and old products read this. */
  stock: Record<Size, number>;
  /** Stock per colour and size: { [colorId]: { XS: 2, S: 4, … } }. Missing on old products → `stock` is used. */
  colorStock?: Record<string, Record<Size, number>>;
  soldOut: boolean;
  secret?: boolean; // true → only shown inside the locked "secret section"
};

export type CartLine = {
  productId: string;
  size: Size;
  fit: Fit;
  colorId: string;
  qty: number;
};

export type Lang = "en" | "ar";

export type NavCat = Exclude<Cat, "all">;

/** Texts on the storefront whose font size the admin can change. */
export type TextKey =
  | "heroKicker"
  | "heroTitle"
  | "heroSub"
  | "featureKicker"
  | "featureTitle"
  | "featureBody";

/** Font size is a percentage of the normal size (100 = unchanged). */
export const SIZE_MIN = 50;
export const SIZE_MAX = 300;
export const SIZE_STEP = 10;

/** Everything the admin can edit on the storefront, stored once per language. */
export type SiteContent = {
  sizes?: Partial<Record<TextKey, number>>; // font size per text, in % (missing = 100)
  announcement: string;
  heroKicker: string;
  heroTitle: string;
  heroSub: string;
  heroImages: string[]; // 1–3 images (laptop / landscape)
  heroImagesMobile: string[]; // 0–3 portrait images for phones (empty → laptop images are used)
  heroCat: NavCat; // where the hero button goes ("Shop <category>")
  featureKicker: string;
  featureTitle: string;
  featureBody: string;
  featureProductId: string; // linked product — drives the image and button
};

export const MAX_HERO_IMAGES = 3;

export type Settings = {
  content: Record<Lang, SiteContent>;
  shamCashId: string;
  shamCashName: string;
  shamCashQr: string; // uploaded picture of the Sham Cash QR code ("" → a generated one is shown)
  telegramBotToken: string;
  telegramChatId: string;
  adminPin: string;
  secretCode: string; // code that opens the secret section (local/demo mode)
};

export type OrderItem = {
  productId: string;
  colorId?: string;
  name: string;
  size: Size;
  fit: Fit;
  color: string;
  qty: number;
  unitPrice: number;
};

export type Order = {
  ref: string;
  createdAt: string;
  customer: {
    name: string;
    phone: string;
    city: string;
    address: string;
  };
  shipping: { id: string; label: string; fee: number };
  items: OrderItem[];
  subtotal: number;
  discount?: number; // coupon discount on the items (shipping is never discounted)
  coupon?: string | null; // coupon code used on this order
  total: number;
  payment: "Sham Cash";
  receiptDataUrl: string;
  telegram: "sent" | "failed" | "unconfigured";
  status: "pending" | "confirmed" | "fulfilled" | "cancelled"; // cancelled = final: stock and coupon use are given back
};

export const CITIES = [
  "Damascus",
  "Rural Damascus",
  "Aleppo",
  "Homs",
  "Hama",
  "Latakia",
  "Tartus",
  "Idlib",
  "Daraa",
  "As-Suwayda",
  "Quneitra",
  "Deir ez-Zor",
  "Raqqa",
  "Al-Hasakah",
] as const;

/** One governorate the store ships to. Edited in the admin ("الشحن والعروض"), stored in `shipping_zones`. */
export type ShippingZone = {
  city: string;
  enabled: boolean;
  fee: number;
  etaAr: string;
  etaEn: string;
  sortOrder: number;
};

const zone = (city: string, fee: number, etaAr: string, etaEn: string, sortOrder: number): ShippingZone => ({
  city,
  enabled: true,
  fee,
  etaAr,
  etaEn,
  sortOrder,
});

/** Used before the database answers (or in demo mode without Supabase). */
export const DEFAULT_SHIPPING_ZONES: ShippingZone[] = [
  zone("Damascus", 4, "من يوم إلى يومين", "1–2 days", 1),
  zone("Rural Damascus", 6, "2–4 أيام", "2–4 days", 2),
  zone("Aleppo", 6, "2–4 أيام", "2–4 days", 3),
  zone("Homs", 6, "2–4 أيام", "2–4 days", 4),
  zone("Hama", 6, "2–4 أيام", "2–4 days", 5),
  zone("Latakia", 6, "2–4 أيام", "2–4 days", 6),
  zone("Tartus", 6, "2–4 أيام", "2–4 days", 7),
  zone("Idlib", 9, "3–6 أيام", "3–6 days", 8),
  zone("Daraa", 9, "3–6 أيام", "3–6 days", 9),
  zone("As-Suwayda", 9, "3–6 أيام", "3–6 days", 10),
  zone("Quneitra", 9, "3–6 أيام", "3–6 days", 11),
  zone("Deir ez-Zor", 9, "3–6 أيام", "3–6 days", 12),
  zone("Raqqa", 9, "3–6 أيام", "3–6 days", 13),
  zone("Al-Hasakah", 9, "3–6 أيام", "3–6 days", 14),
];

/** A discount code (the customer never reads this table; the database validates it). */
export type Coupon = {
  id: string;
  code: string;
  type: "percent" | "fixed";
  value: number;
  minOrder: number;
  maxUses: number | null;
  usedCount: number;
  startsAt: string | null; // ISO
  endsAt: string | null; // ISO
  active: boolean;
};


export const NAV: { label: string; cat: Exclude<Cat, "all"> }[] = [
  { label: "New Drops", cat: "new" },
  { label: "Best Sellers", cat: "bestsellers" },
  { label: "Shirts", cat: "shirts" },
  { label: "Blouses", cat: "hoodies" },
  { label: "T-Shirt", cat: "tees" },
  { label: "Jackets", cat: "jackets" },
  { label: "Pants", cat: "pants" },
  { label: "Shorts", cat: "shorts" },
  { label: "Sets", cat: "sets" },
];

export const CAT_LABEL: Record<Cat, string> = {
  all: "All products",
  new: "New drops",
  bestsellers: "Best sellers",
  shirts: "Shirts",
  hoodies: "Blouses",
  tees: "T-Shirt",
  jackets: "Jackets",
  pants: "Pants",
  shorts: "Shorts",
  sets: "Sets",
  sale: "Sale",
};

const stock = (patch: Partial<Record<Size, number>> = {}): Record<Size, number> => ({
  XS: patch.XS ?? 6,
  S: patch.S ?? 10,
  M: patch.M ?? 12,
  L: patch.L ?? 10,
  XL: patch.XL ?? 6,
  XXL: patch.XXL ?? 4,
  "3XL": patch["3XL"] ?? 0,
});

export const defaultContent: Record<Lang, SiteContent> = {
  en: {
    announcement:
      "SHIPPING ACROSS SYRIA  ·  SHAM CASH PAYMENT AVAILABLE  ·  SEASON 04 IS LIVE",
    heroKicker: "Season collection",
    heroTitle: "New Drop",
    heroSub: "Heavyweight hoodies, tees, and sets. Cut oversize. Paid with Sham Cash.",
    heroImages: ["/media/hero.jpg"],
    heroImagesMobile: [],
    heroCat: "new",
    featureKicker: "The cut",
    featureTitle: "Built heavy. Worn after dark.",
    featureBody:
      "Fleece with a dense hand, shoulders dropped, owl kept tonal. Sets are cut as one silhouette — hoodie and trouser, nothing extra.",
    featureProductId: "crest-noir",
  },
  ar: {
    announcement: "شحن لكل المحافظات السورية  ·  الدفع عبر شام كاش متاح  ·  الموسم 04 متوفر الآن",
    heroKicker: "مجموعة الموسم",
    heroTitle: "الإصدار الجديد",
    heroSub: "هوديات وتيشيرتات وأطقم ثقيلة الوزن. قصّة واسعة. الدفع عبر شام كاش.",
    heroImages: ["/media/hero.jpg"],
    heroImagesMobile: [],
    heroCat: "new",
    featureKicker: "القصّة",
    featureTitle: "صُنعت ثقيلة. تُلبس بعد الظلام.",
    featureBody:
      "قماش فليس كثيف الملمس، أكتاف مائلة، والبومة بنفس اللون. الأطقم مقصوصة كقطعة واحدة — هودي وبنطلون، بلا زيادة.",
    featureProductId: "crest-noir",
  },
};

export const defaultSettings: Settings = {
  content: defaultContent,
  shamCashId: "OWL-SC-448291",
  shamCashName: "OWL STORE",
  shamCashQr: "",
  telegramBotToken: "",
  telegramChatId: "",
  adminPin: "OWL-2026",
  secretCode: "1234",
};

/** Products shown to everyone (the secret-section ones are left out). */
export const publicProducts = (list: Product[]) => list.filter((product) => !product.secret);

export const seedProducts: Product[] = [
  {
    id: "night-archive",
    slug: "night-archive-hoodie",
    name: "Night Archive Hoodie",
    price: 148,
    compareAt: 178,
    tags: ["new", "hoodies"],
    description:
      "Heavyweight fleece, dropped shoulder, double-lined hood. The night uniform — tonal owl, cut oversize.",
    details: [
      "480gsm heavyweight fleece",
      "Dropped shoulder, double-lined hood",
      "Tone-on-tone owl embroidery",
      "Kangaroo pocket, rib cuffs",
    ],
    images: ["/media/night-1.jpg", "/media/night-2.jpg"],
    video: "/media/night-walk.mp4",
    colors: [{ id: "night", name: "Night", hex: "#161616" }],
    fits: ["Oversize", "Boxy Fit"],
    stock: stock({ XS: 2, XXL: 0 }),
    soldOut: false,
  },
  {
    id: "bone-structure",
    slug: "bone-structure-hoodie",
    name: "Bone Structure Hoodie",
    price: 154,
    compareAt: null,
    tags: ["new", "hoodies"],
    description:
      "Boxy bone fleece with a dense hand-feel. The light piece in a dark wardrobe.",
    details: [
      "480gsm brushed fleece",
      "Boxy body, shorter hem",
      "Charcoal owl embroidery",
      "Rib hem and cuffs",
    ],
    images: ["/media/bone-1.jpg", "/media/bone-2.jpg"],
    video: "",
    colors: [{ id: "bone", name: "Bone", hex: "#e7e0d2" }],
    fits: ["Boxy Fit"],
    stock: stock({ XS: 4, XXL: 2 }),
    soldOut: false,
  },
  {
    id: "smoke-column",
    slug: "smoke-column-tee",
    name: "Smoke Column Tee",
    price: 64,
    compareAt: 78,
    tags: ["tees"],
    description: "320gsm boxy tee. Smoke grey, dropped shoulder, owl at the chest.",
    details: ["320gsm jersey", "Boxy, dropped shoulder", "Owl embroidery", "Pre-shrunk"],
    images: ["/media/smoke-1.jpg", "/media/smoke-2.jpg"],
    video: "",
    colors: [{ id: "smoke", name: "Smoke", hex: "#8d8d90" }],
    fits: ["Boxy Fit", "Regular Fit"],
    stock: stock({ XS: 0, XXL: 1 }),
    soldOut: false,
  },
  {
    id: "ink-standard",
    slug: "ink-standard-tee",
    name: "Ink Standard Tee",
    price: 68,
    compareAt: null,
    tags: ["tees"],
    description:
      "The regular-fit essential. Ink black, heavy jersey — currently gone.",
    details: ["Heavy jersey", "Regular fit", "Tonal owl", "Crew neck"],
    images: ["/media/ink-1.jpg", "/media/ink-2.jpg"],
    video: "",
    colors: [{ id: "ink", name: "Ink", hex: "#111111" }],
    fits: ["Regular Fit"],
    stock: stock({ XS: 0, S: 0, M: 0, L: 0, XL: 0, XXL: 0 }),
    soldOut: true,
  },
  {
    id: "crest-noir",
    slug: "crest-noir-set",
    name: "Crest Noir Set",
    price: 220,
    compareAt: null,
    tags: ["new", "sets"],
    description:
      "Hoodie and trouser, cut as one silhouette. Oversize through the shoulder, straight through the leg.",
    details: [
      "Matching hoodie and trouser",
      "Oversize shoulder, straight leg",
      "Tonal owl on the chest",
      "Sold as a set",
    ],
    images: ["/media/crest-1.jpg", "/media/night-2.jpg"],
    video: "",
    colors: [{ id: "night", name: "Night", hex: "#141414" }],
    fits: ["Oversize"],
    stock: stock({ XS: 0, XXL: 2 }),
    soldOut: false,
  },
];

export const CATALOG_VERSION = 1;

export function cloneSeed(): Product[] {
  return seedProducts.map((product) => ({
    ...product,
    colors: product.colors.map((color) => ({ ...color })),
    fits: [...product.fits],
    tags: [...product.tags],
    images: [...product.images],
    details: [...product.details],
    stock: { ...product.stock },
  }));
}

export function money(value: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value);
}

export function isSoldOut(product: Product) {
  if (product.soldOut) return true;
  return SIZES.every((size) => (product.stock[size] ?? 0) <= 0);
}

/** Sizes shown to customers: the standard ones, plus 3XL only when it is in stock. */
export function visibleSizes(product: Product, colorId?: string | null): readonly Size[] {
  const byColor = colorId ? product.colorStock?.[colorId] : undefined;
  const source = byColor ?? product.stock;
  return SIZES.filter((size) => size !== "3XL" || (source[size] ?? 0) > 0);
}

/** Pieces left of a size. Pass the colour to get that colour's stock (falls back to the size total on old products). */
export function sizeLeft(product: Product, size: Size, colorId?: string) {
  if (product.soldOut) return 0;
  const byColor = colorId ? product.colorStock?.[colorId] : undefined;
  if (byColor) return Math.max(0, byColor[size] ?? 0);
  return Math.max(0, product.stock[size] ?? 0);
}

/** Does this product track stock per colour? */
export function hasColorStock(product: Product) {
  return Boolean(product.colorStock && Object.keys(product.colorStock).length);
}

export function matchesCat(product: Product, cat: Cat) {
  if (cat === "all") return true;
  if (cat === "sale") return product.compareAt != null && product.compareAt > product.price;
  return product.tags.includes(cat);
}

export function isCat(value: unknown): value is Cat {
  return typeof value === "string" && (CATS as readonly string[]).includes(value);
}

export function slugify(name: string) {
  const slug = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
  return slug || "piece";
}

/** Arabic-Indic (٠-٩) and Persian (۰-۹) digits → 0-9, so phone numbers typed on an Arabic keyboard pass validation. */
export function normalizeDigits(value: string) {
  return value
    .replace(/[\u0660-\u0669]/g, (ch) => String(ch.charCodeAt(0) - 0x0660))
    .replace(/[\u06f0-\u06f9]/g, (ch) => String(ch.charCodeAt(0) - 0x06f0));
}

export function makeRef() {
  const n = Math.floor(1000 + Math.random() * 9000);
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const letter = alphabet[Math.floor(Math.random() * alphabet.length)];
  return `OWL-${n}${letter}`;
}

export function formatOrderText(order: Order) {
  const lines = order.items.map(
    (item) =>
      `• ${item.name}\n  ${item.size} · ${item.fit} · ${item.color} · qty ${item.qty} · ${money(item.unitPrice * item.qty)}`,
  );
  return [
    "OWL STORE — NEW ORDER",
    `Ref: ${order.ref}`,
    "",
    `Name: ${order.customer.name}`,
    `Phone: ${order.customer.phone}`,
    `City: ${order.customer.city}`,
    `Address: ${order.customer.address}`,
    `Delivery: ${order.shipping.label}`,
    "",
    "Items:",
    ...lines,
    "",
    `Subtotal: ${money(order.subtotal)}`,
    ...(order.discount && order.discount > 0
      ? [`Discount${order.coupon ? ` (${order.coupon})` : ""}: -${money(order.discount)}`]
      : []),
    `Shipping: ${money(order.shipping.fee)}`,
    `Total: ${money(order.total)}`,
    "Payment: Sham Cash",
  ].join("\n");
}

export function blankProduct(): Product {
  const id = crypto.randomUUID();
  return {
    id,
    slug: `new-piece-${id.slice(0, 4)}`,
    name: "New piece",
    price: 80,
    compareAt: null,
    tags: ["new"],
    description: "Describe the cut, the hand, and how it sits.",
    details: ["Heavyweight cotton", "Tonal owl embroidery"],
    images: ["/media/night-1.jpg", "/media/night-2.jpg"],
    video: "",
    colors: [{ id: "night", name: "Night", hex: "#1a1a1a" }],
    fits: ["Oversize"],
    stock: stock(),
    soldOut: false,
  };
}

// ---------- Language helpers ----------

export const NAV_LABEL: Record<Lang, Record<NavCat, string>> = {
  en: {
    new: "New Drops",
    bestsellers: "Best Sellers",
    shirts: "Shirts",
    hoodies: "Blouses",
    tees: "T-Shirt",
    jackets: "Jackets",
    pants: "Pants",
    shorts: "Shorts",
    sets: "Sets",
    sale: "Sale",
  },
  ar: {
    new: "الجديد",
    bestsellers: "الأكثر مبيعاً",
    shirts: "قمصان",
    hoodies: "بلوزات",
    tees: "T-Shirt",
    jackets: "جواكيت",
    pants: "بناطيل",
    shorts: "شورتات",
    sets: "سيت",
    sale: "تخفيضات",
  },
};

/** Text on a "shop" button for a category, e.g. "Shop sets" / "تسوق الأطقم". */
const SHOP_WORD: Record<Lang, Record<NavCat, string>> = {
  en: {
    new: "Shop new drops",
    bestsellers: "Shop best sellers",
    shirts: "Shop shirts",
    hoodies: "Shop blouses",
    tees: "Shop T-Shirt",
    jackets: "Shop jackets",
    pants: "Shop pants",
    shorts: "Shop shorts",
    sets: "Shop sets",
    sale: "Shop sale",
  },
  ar: {
    new: "تسوق الجديد",
    bestsellers: "تسوق الأكثر مبيعاً",
    shirts: "تسوق القمصان",
    hoodies: "تسوق البلوزات",
    tees: "تسوق T-Shirt",
    jackets: "تسوق الجواكيت",
    pants: "تسوق البناطيل",
    shorts: "تسوق الشورتات",
    sets: "تسوق السيت",
    sale: "تسوق التخفيضات",
  },
};

export function shopLabel(lang: Lang, cat: NavCat) {
  return SHOP_WORD[lang][cat];
}

/** The "kind" of a product (hoodies / tees / pants / shorts / sets), used to label buttons that link to it. */
export function productCat(product: Product | undefined): NavCat {
  if (!product) return "sets";
  for (const cat of ["sets", "shirts", "hoodies", "jackets", "pants", "shorts", "tees"] as const) {
    if (product.tags.includes(cat)) return cat;
  }
  return "new";
}

/** Fill any missing fields (older saved data, partial database rows) from the defaults. */
export function normalizeContent(value: unknown): Record<Lang, SiteContent> {
  const input = (value ?? {}) as Partial<Record<Lang, Partial<SiteContent>>>;
  const out = {} as Record<Lang, SiteContent>;
  for (const lang of ["en", "ar"] as const) {
    const merged = { ...defaultContent[lang], ...(input[lang] ?? {}) };
    const images = Array.isArray(merged.heroImages)
      ? merged.heroImages.filter((src) => typeof src === "string" && src).slice(0, MAX_HERO_IMAGES)
      : [];
    const mobile = Array.isArray(merged.heroImagesMobile)
      ? merged.heroImagesMobile.filter((src) => typeof src === "string" && src).slice(0, MAX_HERO_IMAGES)
      : [];
    const rawSizes = (merged.sizes ?? {}) as Record<string, unknown>;
    const sizes: Partial<Record<TextKey, number>> = {};
    for (const [key, value] of Object.entries(rawSizes)) {
      if (typeof value === "number" && Number.isFinite(value)) {
        sizes[key as TextKey] = Math.min(SIZE_MAX, Math.max(SIZE_MIN, Math.round(value)));
      }
    }
    out[lang] = {
      ...merged,
      sizes,
      heroImages: images.length ? images : defaultContent[lang].heroImages,
      heroImagesMobile: mobile,
      heroCat: (CATS as readonly string[]).includes(merged.heroCat) && merged.heroCat !== "all"
        ? merged.heroCat
        : "new",
    };
  }
  return out;
}

export function catLabel(lang: Lang, cat: Cat) {
  if (cat === "all") return lang === "ar" ? "كل المنتجات" : "All Products";
  return NAV_LABEL[lang][cat];
}
